﻿# Jex-autobot-7.2.2 python based 

## usages:
### you need the latest python installed in your computer to run
![jex](https://user-images.githubusercontent.com/42300174/111040322-ad0b7900-845c-11eb-972a-ea6479b6a411.PNG)
